# tic-tac-toe
How to make own tic tac toe game play two way first play with computer and second way play with player using pure html css and javascript
